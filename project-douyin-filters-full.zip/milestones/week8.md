# Week 8 任务 | Week 8 Tasks

## 中文
- Mockup 迭代：增加参数滑块“归零”、提示层文字。
- 测试交互可视化功能（筛选/标签）。
- 撰写论文 Methodology 完整版。

## English
- Iterate mockup: add "reset to zero" parameter sliders and hint texts.
- Test interactive visualization features (filtering/tags).
- Write full version of Methodology section.
