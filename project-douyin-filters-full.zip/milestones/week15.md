# Week 15 任务 | Week 15 Tasks

## 中文
- 提交完整论文初稿（4000+ 字）。
- 根据导师反馈修改。
- 确保 GitHub 完整。

## English
- Submit full paper draft (4000+ words).
- Revise based on supervisor feedback.
- Ensure GitHub repository is complete.
