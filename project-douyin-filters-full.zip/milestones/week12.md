# Week 12 任务 | Week 12 Tasks

## 中文
- 完成论文 Conclusion 草稿。
- 全文字数约 3500。
- 开始整理 References 与附录。

## English
- Draft Conclusion section of the paper.
- Paper word count ~3500.
- Start compiling References and Appendices.
