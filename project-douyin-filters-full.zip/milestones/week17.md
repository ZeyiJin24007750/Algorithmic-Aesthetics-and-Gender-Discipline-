# Week 17 (Final Week) 任务 | Week 17 (Final Week) Tasks

## 中文
提交最终成果：
- 论文 PDF（5000+ 字）
- 视频短片
- GitHub
- A small-format zine

## English
Submit final deliverables:
- Paper PDF (5000+ words)
- Video short film
- GitHub repository
- A small-format zine
