# Week 7 任务 | Week 7 Tasks

## 中文
- 初步 Figma Mockup：新增多元默认值（自然肤色、深肤、皱纹保留）。
- 继续优化数据可视化：语义网络图/时间轴。
- 论文累计字数约 1500–2000。

## English
- Create initial Figma mockup: introduce diverse defaults (natural skin tones, dark skin, wrinkles).
- Continue improving data visualization: semantic networks / timelines.
- Paper cumulative word count ~1500–2000.
