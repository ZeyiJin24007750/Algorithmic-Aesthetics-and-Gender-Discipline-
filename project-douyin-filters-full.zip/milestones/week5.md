# Week 5 任务 | Week 5 Tasks

## 中文
- 完成数据收集（120+ 滤镜截图）。
- 数据清理与注释，建立最终数据库（CSV/Excel）。
- 开始论文 Results 初稿（描述数据趋势）。

## English
- Complete data collection (120+ filter screenshots).
- Clean and annotate data, build final database (CSV/Excel).
- Begin drafting Results section (describe data trends).
