# Week 6 任务 | Week 6 Tasks

## 中文
- 开始界面再设计草图（纸面草图—Figma）。
- 绘制“现有默认界面” vs “多元默认界面”对比草图。
- 撰写论文 Literature Review 第三部分（算法审美与界面政治）。

## English
- Start interface redesign sketches (paper sketches → Figma).
- Draw comparison sketches: "current default interface" vs "diverse default interface".
- Write third part of Literature Review (algorithmic aesthetics and interface politics).
