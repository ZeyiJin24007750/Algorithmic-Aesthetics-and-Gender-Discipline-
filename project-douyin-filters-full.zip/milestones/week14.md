# Week 14 任务 | Week 14 Tasks

## 中文
- 完成视频短片成片（2–4 分钟）。
- a small-format zine 制作。
- 论文排版与格式修正。

## English
- Complete final video (2–4 minutes).
- Produce a small-format zine.
- Format and typeset paper.
