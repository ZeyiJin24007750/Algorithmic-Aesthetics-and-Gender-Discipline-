# Week 16 任务 | Week 16 Tasks

## 中文
- 最终修订论文（5000+ 字）。
- 最终修订视频。
- 准备 10 分钟 Presentation。

## English
- Final revision of paper (5000+ words).
- Final revision of video.
- Prepare 10-minute presentation.
