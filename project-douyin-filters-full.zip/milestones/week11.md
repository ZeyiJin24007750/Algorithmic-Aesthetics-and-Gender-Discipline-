# Week 11 任务 | Week 11 Tasks

## 中文
- 自我评估 Mockup + 可视化：记录优势与局限。
- 准备视频短片 storyboard（展示现有界面 vs 改造界面）。
- 开始论文 Discussion 初稿。

## English
- Self-evaluate mockup and visualizations: record strengths and limitations.
- Prepare video storyboard (showing current interface vs redesigned interface).
- Begin drafting Discussion section.
