# Week 4 任务 | Week 4 Tasks

## 中文
- 数据扩展到 100+ 张截图，开始整理统计参数（默认值平均、美白比例）。
- 初步绘制数据可视化草图（柱状图 / 语义图）。
- 在 GitHub 上传早期可视化成果。
- 撰写论文 Literature Review 第二部分（中国数字文化与“白瘦幼”）。

## English
- Expand dataset to 100+ screenshots and calculate statistics (average default values, whitening ratios).
- Create preliminary data visualization sketches (bar charts / semantic maps).
- Upload early visualization results to GitHub.
- Write second part of Literature Review (Chinese digital culture and “white-thin-young” aesthetic).
