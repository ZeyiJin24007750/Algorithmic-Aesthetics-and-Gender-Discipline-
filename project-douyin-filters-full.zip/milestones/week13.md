# Week 13 任务 | Week 13 Tasks

## 中文
- 收集视频素材（界面操作录屏、Mockup 画面）。
- 配音与剪辑初稿。
- 论文润色，逻辑串联。

## English
- Collect video materials (UI recordings, mockup visuals).
- Record narration and create first edit of video.
- Revise and refine paper logic and flow.
