# Week 3 任务 | Week 3 Tasks

## 中文
- 数据扩展到 60–80 张截图，完成初步分类（肤色相关、脸型相关、幼态化相关）。
- 初步文本分析滤镜命名模式。
- 撰写论文 Methodology 初稿。

## English
- Expand dataset to 60–80 screenshots, complete preliminary categorization (skin tone, facial structure, infantilization).
- Conduct initial textual analysis of filter naming patterns.
- Draft Methodology section of the paper.
