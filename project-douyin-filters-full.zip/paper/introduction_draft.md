# Introduction 草稿 | Introduction Draft

## 中文
（这里填写约 500 字的论文引言初稿，聚焦抖音默认滤镜与性别规训的研究背景与问题意识。）

## English
(Write ~500 words draft of the paper introduction, focusing on Douyin default filters and gender discipline.)
